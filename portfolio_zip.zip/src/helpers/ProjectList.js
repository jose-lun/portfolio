import Taylor from "../assets/Taylor.png";

export const ProjectList = [
    {
        name: "Taylor Series: Intuition and Applications",
        image: Taylor
    }
]